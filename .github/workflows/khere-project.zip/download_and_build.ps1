# PowerShell script to download portable Java and build APK
# This creates a portable build environment

$ErrorActionPreference = "Stop"

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Portable Android Build Setup" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

$BUILD_DIR = "$PWD\portable_build"
$JAVA_DIR = "$BUILD_DIR\java"
$GRADLE_DIR = "$BUILD_DIR\gradle"

# Create directories
New-Item -ItemType Directory -Force -Path $BUILD_DIR | Out-Null
New-Item -ItemType Directory -Force -Path $JAVA_DIR | Out-Null
New-Item -ItemType Directory -Force -Path "$GRADLE_DIR" | Out-Null

Write-Host "[1/4] Checking Java..." -ForegroundColor Yellow

# Check if Java is available
$javaFound = $false
try {
    $javaVersion = java -version 2>&1 | Select-Object -First 1
    if ($javaVersion -match "version") {
        Write-Host "Java found: $javaVersion" -ForegroundColor Green
        $JAVA_HOME = $env:JAVA_HOME
        if (-not $JAVA_HOME) {
            # Try to find Java
            $possiblePaths = @(
                "C:\Program Files\Java\jdk-*",
                "C:\Program Files\Eclipse Adoptium\jdk-*",
                "C:\Program Files (x86)\Java\jdk-*"
            )
            foreach ($path in $possiblePaths) {
                if (Test-Path $path) {
                    $JAVA_HOME = (Get-Item $path | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
                    break
                }
            }
        }
        $javaFound = $true
    }
}
catch {
    Write-Host "Java not found in PATH" -ForegroundColor Yellow
}

if (-not $javaFound) {
    Write-Host ""
    Write-Host "Java JDK is required to build Android apps." -ForegroundColor Red
    Write-Host ""
    Write-Host "Option 1: Install Java globally" -ForegroundColor Cyan
    Write-Host "  1. Download from: https://adoptium.net/temurin/releases/" -ForegroundColor White
    Write-Host "  2. Install Java JDK" -ForegroundColor White
    Write-Host "  3. Run this script again" -ForegroundColor White
    Write-Host ""
    Write-Host "Option 2: Use online build service" -ForegroundColor Cyan
    Write-Host "  1. Create a GitHub repository" -ForegroundColor White
    Write-Host "  2. Push this code to GitHub" -ForegroundColor White
    Write-Host "  3. Use GitHub Actions to build" -ForegroundColor White
    Write-Host ""
    Write-Host "Option 3: Use Android Studio" -ForegroundColor Cyan
    Write-Host "  This is the easiest and most reliable method" -ForegroundColor White
    Write-Host "  Download: https://developer.android.com/studio" -ForegroundColor White
    Write-Host ""
    
    $choice = Read-Host "Would you like to (1) Download portable Java, (2) See online build guide, (3) Exit"
    
    if ($choice -eq "1") {
        Write-Host ""
        Write-Host "Downloading portable Java..." -ForegroundColor Yellow
        Write-Host "URL: https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse" -ForegroundColor Gray
        
        # Download URL for portable Java
        $javaUrl = "https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.8%2B7/OpenJDK17U-jdk_x64_windows_hotspot_17.0.8_7.zip"
        $javaZip = "$BUILD_DIR\java.zip"
        
        Write-Host "This will download ~190MB..." -ForegroundColor Yellow
        Invoke-WebRequest -Uri $javaUrl -OutFile $javaZip -UseBasicParsing
        
        Write-Host "Extracting..." -ForegroundColor Yellow
        Expand-Archive -Path $javaZip -DestinationPath $JAVA_DIR -Force
        Remove-Item $javaZip
        
        # Find the Java folder
        $javaFolder = Get-ChildItem -Path $JAVA_DIR -Directory | Select-Object -First 1
        $JAVA_HOME = $javaFolder.FullName
        
        Write-Host "Java installed at: $JAVA_HOME" -ForegroundColor Green
        $env:JAVA_HOME = $JAVA_HOME
        $env:PATH = "$JAVA_HOME\bin;$env:PATH"
        $javaFound = $true
    }
    elseif ($choice -eq "2") {
        Write-Host ""
        Write-Host "For online building, see: BUILD_WITHOUT_ANDROID_STUDIO.md" -ForegroundColor Cyan
        exit
    }
    else {
        exit
    }
}

if (-not $javaFound) {
    exit
}

Write-Host ""
Write-Host "[2/4] Setting up Gradle..." -ForegroundColor Yellow

# Check if gradle wrapper exists
if (-not (Test-Path "gradle\wrapper\gradle-wrapper.jar")) {
    Write-Host "Downloading Gradle wrapper..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Force -Path "gradle\wrapper" | Out-Null
    
    # Download gradle wrapper
    $gradleVersion = "7.5"
    $wrapperUrl = "https://raw.githubusercontent.com/gradle/gradle/v$gradleVersion/gradle/wrapper/gradle-wrapper.jar"
    
    try {
        Invoke-WebRequest -Uri $wrapperUrl -OutFile "gradle\wrapper\gradle-wrapper.jar" -UseBasicParsing
        Write-Host "Gradle wrapper downloaded" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed to download gradle wrapper" -ForegroundColor Red
        Write-Host "You can manually download it from:" -ForegroundColor Yellow
        Write-Host "  https://raw.githubusercontent.com/gradle/gradle/v7.5/gradle/wrapper/gradle-wrapper.jar" -ForegroundColor Gray
        exit
    }
}

Write-Host ""
Write-Host "[3/4] Checking Android SDK..." -ForegroundColor Yellow

# Try to find Android SDK
$androidHome = $null
$possibleAndroidPaths = @(
    $env:ANDROID_HOME,
    "$env:LOCALAPPDATA\Android\Sdk",
    "C:\Android\Sdk",
    "$env:ProgramFiles\Android\Sdk",
    "$env:ProgramFiles(x86)\Android\Sdk"
)

foreach ($path in $possibleAndroidPaths) {
    if ($path -and (Test-Path $path)) {
        $androidHome = $path
        Write-Host "Found Android SDK at: $androidHome" -ForegroundColor Green
        break
    }
}

if (-not $androidHome) {
    Write-Host ""
    Write-Host "Android SDK not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "You can install:"
    Write-Host "  1. Android Studio (includes SDK)"
    Write-Host "  2. Android Command Line Tools"
    Write-Host ""
    Write-Host "Without SDK, you cannot build Android apps."
    Write-Host ""
    Write-Host "Easiest: Install Android Studio from:"
    Write-Host "  https://developer.android.com/studio" -ForegroundColor Cyan
    Write-Host ""
    
    $installSdk = Read-Host "Would you like me to download command-line tools? (y/n)"
    
    if ($installSdk -eq "y" -or $installSdk -eq "Y") {
        Write-Host ""
        Write-Host "Downloading Android SDK..." -ForegroundColor Yellow
        
        # This would require downloading and setting up Android SDK
        Write-Host "Android SDK setup requires manual configuration." -ForegroundColor Yellow
        Write-Host "Please install Android Studio for the easiest setup." -ForegroundColor Yellow
        exit
    }
    else {
        Write-Host "Build cancelled. Please install Android Studio or Android SDK." -ForegroundColor Yellow
        exit
    }
}

Write-Host ""
Write-Host "[4/4] Building APK..." -ForegroundColor Yellow
Write-Host ""

# Set environment variables
$env:ANDROID_HOME = $androidHome
$env:PATH = "$env:ANDROID_HOME\platform-tools;$env:ANDROID_HOME\tools;$env:PATH"

# Build the APK
try {
    & ".\gradlew.bat" assembleDebug
    
    if (Test-Path "app\build\outputs\apk\debug\app-debug.apk") {
        Write-Host ""
        Write-Host "================================================" -ForegroundColor Green
        Write-Host "  APK Built Successfully!" -ForegroundColor Green
        Write-Host "================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "APK Location:" -ForegroundColor Cyan
        Write-Host "  $PWD\app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor White
        Write-Host ""
        Write-Host "Size: $((Get-Item 'app\build\outputs\apk\debug\app-debug.apk').Length / 1MB) MB" -ForegroundColor Green
        Write-Host ""
    }
    else {
        Write-Host ""
        Write-Host "Build completed but APK not found." -ForegroundColor Yellow
        Write-Host "Check the errors above for details." -ForegroundColor Yellow
    }
}
catch {
    Write-Host ""
    Write-Host "Build failed!" -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "For troubleshooting, see:" -ForegroundColor Cyan
    Write-Host "  BUILD_WITHOUT_ANDROID_STUDIO.md" -ForegroundColor White
}

