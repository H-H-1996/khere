# Auto-install Java and build APK
# This script automatically sets up everything needed

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Automatic Android Build Setup" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

Write-Host "[1/4] Checking winget..." -ForegroundColor Yellow
$wingetPath = where.exe winget
if ($wingetPath) {
    Write-Host "winget found: $wingetPath" -ForegroundColor Green
}
else {
    Write-Host "winget not found. Please install App Installer from Microsoft Store." -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "[2/4] Checking Java..." -ForegroundColor Yellow
try {
    $javaCheck = java -version 2>&1 | Select-Object -First 1
    if ($javaCheck -match "version") {
        Write-Host "Java is already installed: $javaCheck" -ForegroundColor Green
    }
}
catch {
    Write-Host "Java not found. Installing Java JDK 17..." -ForegroundColor Yellow
    Write-Host "This may take a few minutes..." -ForegroundColor Gray
    
    try {
        # Install Eclipse Temurin (OpenJDK)
        winget install -e --id EclipseAdoptium.Temurin.17.JDK --silent --accept-package-agreements --accept-source-agreements
        Write-Host "Java installed successfully!" -ForegroundColor Green
        
        # Refresh PATH
        $env:PATH = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        
        # Wait a bit for installation to complete
        Start-Sleep -Seconds 5
        
        # Verify installation
        try {
            $javaVersion = java -version 2>&1 | Select-Object -First 1
            Write-Host "Java is now available: $javaVersion" -ForegroundColor Green
        }
        catch {
            Write-Host "Java installed but not yet in PATH. Please restart PowerShell and run this script again." -ForegroundColor Yellow
            exit
        }
    }
    catch {
        Write-Host "Failed to install Java automatically." -ForegroundColor Red
        Write-Host "Please install Java manually:" -ForegroundColor Yellow
        Write-Host "  Download: https://adoptium.net/temurin/releases/" -ForegroundColor White
        Write-Host "  Or run: winget install EclipseAdoptium.Temurin.17.JDK" -ForegroundColor White
        exit
    }
}

Write-Host ""
Write-Host "[3/4] Checking Android SDK..." -ForegroundColor Yellow

# Try to find existing Android SDK
$androidSDK = $null
$possiblePaths = @(
    $env:ANDROID_HOME,
    "$env:LOCALAPPDATA\Android\Sdk",
    "C:\Android\Sdk",
    "C:\Program Files\Android\Sdk"
)

foreach ($path in $possiblePaths) {
    if ($path -and (Test-Path $path)) {
        $androidSDK = $path
        Write-Host "Android SDK found at: $androidSDK" -ForegroundColor Green
        break
    }
}

if (-not $androidSDK) {
    Write-Host ""
    Write-Host "Android SDK is required but not found." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  1. Install Android Studio (recommended)" -ForegroundColor White
    Write-Host "  2. Use GitHub Actions to build in the cloud" -ForegroundColor White
    Write-Host ""
    Write-Host "Easiest: Install Android Studio:" -ForegroundColor Cyan
    Write-Host "  Download: https://developer.android.com/studio" -ForegroundColor White
    Write-Host ""
    
    $choice = Read-Host "Do you want to download Android Studio now? (y/n)"
    
    if ($choice -eq "y" -or $choice -eq "Y") {
        Write-Host ""
        Write-Host "Downloading Android Studio..." -ForegroundColor Yellow
        winget install -e --id Google.AndroidStudio --silent --accept-package-agreements --accept-source-agreements
        
        Write-Host ""
        Write-Host "Android Studio installing..." -ForegroundColor Yellow
        Write-Host "After installation, please:" -ForegroundColor Cyan
        Write-Host "  1. Open Android Studio" -ForegroundColor White
        Write-Host "  2. Let it finish the setup wizard" -ForegroundColor White
        Write-Host "  3. Run this script again or use Android Studio to build" -ForegroundColor White
        exit
    }
    else {
        Write-Host ""
        Write-Host "Alternative: Use GitHub Actions to build without installing anything!" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Run these commands:" -ForegroundColor Yellow
        Write-Host "  git init" -ForegroundColor White
        Write-Host "  git add ." -ForegroundColor White
        Write-Host "  git commit -m 'First commit'" -ForegroundColor White
        Write-Host "  git remote add origin https://github.com/YOUR_USERNAME/khere.git" -ForegroundColor White
        Write-Host "  git push -u origin main" -ForegroundColor White
        Write-Host ""
        Write-Host "Then the APK will build automatically!" -ForegroundColor Green
        exit
    }
}

Write-Host ""
Write-Host "[4/4] Building APK..." -ForegroundColor Yellow
Write-Host ""

# Set Android SDK environment
$env:ANDROID_HOME = $androidSDK
$env:PATH = "$androidSDK\platform-tools;$androidSDK\tools;$env:PATH"

# Build the APK
try {
    if (Test-Path ".\gradlew.bat") {
        .\gradlew.bat assembleDebug
    }
    else {
        Write-Host "gradlew.bat not found. Please run this script from the project root directory." -ForegroundColor Red
        exit
    }
    
    $apkPath = "app\build\outputs\apk\debug\app-debug.apk"
    if (Test-Path $apkPath) {
        Write-Host ""
        Write-Host "================================================" -ForegroundColor Green
        Write-Host "  APK Built Successfully!" -ForegroundColor Green
        Write-Host "================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "Location:" -ForegroundColor Cyan
        Write-Host "  $PWD\$apkPath" -ForegroundColor White
        Write-Host ""
        
        $fileInfo = Get-Item $apkPath
        Write-Host "Size: $([math]::Round($fileInfo.Length / 1MB, 2)) MB" -ForegroundColor Green
        Write-Host ""
        
        Write-Host "To install on your phone:" -ForegroundColor Cyan
        Write-Host "  1. Transfer APK to your phone" -ForegroundColor White
        Write-Host "  2. Enable 'Install from unknown sources'" -ForegroundColor White
        Write-Host "  3. Open and install the APK" -ForegroundColor White
        Write-Host ""
    }
    else {
        Write-Host ""
        Write-Host "Build completed but APK not found." -ForegroundColor Yellow
        Write-Host "Check for errors above." -ForegroundColor Yellow
    }
}
catch {
    Write-Host ""
    Write-Host "Build failed: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "See SIMPLE_BUILD_GUIDE.txt for troubleshooting" -ForegroundColor Yellow
}

