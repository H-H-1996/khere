# بحث الأرقام - Number Search App (Arabic)

An Android application that allows users to search for Arabic results by entering a number. The app uses SQLite database for data storage.

## Features

- ✅ Full Arabic language support (RTL)
- ✅ Beautiful modern UI with Material Design
- ✅ Number search functionality
- ✅ SQLite database for data storage
- ✅ Sample Arabic data included
- ✅ Easy to customize with your own Excel data

## Project Structure

```
app/
├── src/main/
│   ├── java/com/khere/app/
│   │   ├── MainActivity.java       # Main activity with search functionality
│   │   └── DatabaseHelper.java     # Database helper with sample data
│   ├── res/
│   │   ├── layout/
│   │   │   └── activity_main.xml    # Main layout
│   │   └── values/
│   │       ├── strings.xml          # English strings
│   │       ├── values-ar/
│   │       │   └── strings.xml      # Arabic strings
│   │       ├── colors.xml
│   │       └── styles.xml
│   └── AndroidManifest.xml
└── build.gradle
```

## How to Add Your Excel Data

### Option 1: Manual Entry (Recommended for Small Datasets)

1. Open `app/src/main/java/com/khere/app/DatabaseHelper.java`
2. Locate the `insertSampleData()` method
3. Replace the sample data with your Excel data:

```java
private void insertSampleData(SQLiteDatabase db) {
    String[][] sampleData = {
        {"رقمك", "النتيجة بالعربية"},
        {"1", "نتيجة رقم واحد"},
        {"2", "نتيجة رقم اثنين"},
        // Add your data here...
    };
    
    for (String[] row : sampleData) {
        String insertQuery = "INSERT INTO " + TABLE_NUMBERS + "(" +
                COLUMN_NUMBER + ", " + COLUMN_RESULT + ") VALUES (?, ?)";
        db.execSQL(insertQuery, new String[]{row[0], row[1]});
    }
}
```

### Option 2: Convert Excel to Database

If you have a large Excel file:

1. Export your Excel file to CSV format
2. Use a script or tool to convert CSV to SQL insert statements
3. Add the inserts to the `insertSampleData()` method

### Option 3: Import Database File Directly

1. Create a SQLite database file with your Excel data
2. Place it in `app/src/main/assets/` folder
3. Modify `DatabaseHelper.java` to copy the database from assets if it doesn't exist

## Building the App

### Prerequisites

- Android Studio Arctic Fox or later
- JDK 8 or later
- Android SDK (API level 21+)

### Steps

1. Open the project in Android Studio
2. Wait for Gradle sync to complete
3. Connect your Android device or start an emulator
4. Click "Run" to build and install the app

### Using Command Line

```bash
# Build APK
./gradlew assembleDebug

# Install on connected device
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Using the App

1. Launch the app on your Android device
2. Enter a number in the input field (use the numbers from your Excel sheet)
3. Tap the search button (بحث)
4. The result will be displayed in Arabic below the search button

## Customization

### Changing App Name

Edit `app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">اسم التطبيق الجديد</string>
```

### Changing Colors

Edit `app/src/main/res/values/colors.xml`:
```xml
<color name="colorPrimary">#6200EE</color>
<color name="colorPrimaryDark">#3700B3</color>
<color name="colorAccent">#03DAC5</color>
```

### Adding More Languages

1. Create a new folder in `app/src/main/res/` (e.g., `values-fr/`)
2. Copy `strings.xml` and translate the strings
3. The app will automatically use the correct language based on device settings

## Sample Data

The app comes with sample Arabic data:
- 1: نتيجة رقم واحد
- 2: نتيجة رقم اثنين
- 3: نتيجة رقم ثلاثة
- 10: نتيجة رقم عشرة
- 20: نتيجة رقم عشرين
- 50: نتيجة رقم خمسين
- 100: نتيجة رقم مائة
- 500: نتيجة رقم خمسمائة
- 1000: نتيجة رقم ألف

## Requirements

- Minimum SDK: 21 (Android 5.0)
- Target SDK: 33 (Android 13)

## License

This project is open source and available for modification.

## Support

For issues or questions, please check the code comments in the source files or modify the sample data in `DatabaseHelper.java`.

