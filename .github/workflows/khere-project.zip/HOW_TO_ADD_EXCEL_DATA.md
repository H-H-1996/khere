# How to Add Your Excel Data to the App

This guide will help you import your Excel data into the Android app.

## Method 1: Using CSV File (Easiest)

### Step 1: Convert Excel to CSV

1. Open your Excel file
2. Make sure it has two columns:
   - First column: Number (or any identifier)
   - Second column: Result in Arabic (the text to display)
3. Go to **File → Save As**
4. Choose **CSV (Comma delimited) (*.csv)** format
5. Save the file

### Step 2: Add CSV to the App

1. Copy your CSV file to: `app/src/main/assets/sample_data.csv`
2. Make sure it has a header row: `number,result`
3. Example format:
   ```
   number,result
   1,نتيجة رقم واحد
   2,نتيجة رقم اثنين
   ```

### Step 3: Update DatabaseHelper.java

1. Open `app/src/main/java/com/khere/app/DatabaseHelper.java`
2. Find the `onCreate()` method
3. Comment out `insertSampleData(db);`
4. Uncomment the try-catch block that loads from assets:

```java
@Override
public void onCreate(SQLiteDatabase db) {
    String createTable = "CREATE TABLE " + TABLE_NUMBERS + "(" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_NUMBER + " TEXT NOT NULL," +
            COLUMN_RESULT + " TEXT NOT NULL" +
            ")";
    db.execSQL(createTable);
    
    // Insert sample Arabic data
    // insertSampleData(db);
    
    // To use your Excel data from CSV file, uncomment the following lines:
    try {
        loadDataFromAssets(db);
    } catch (Exception e) {
        // Fall back to sample data if asset file not found
        insertSampleData(db);
    }
}
```

### Step 4: Rebuild the App

1. Clean and rebuild the project
2. Install on your device

**Note:** The database is only created once. If you already installed the app, you need to:
- Uninstall the app from your device, OR
- Increase `DATABASE_VERSION` in DatabaseHelper.java to force database recreation

---

## Method 2: Direct Code Editing (For Small Datasets)

If you have a small dataset (< 100 entries), you can directly edit the code:

### Steps:

1. Open `app/src/main/java/com/khere/app/DatabaseHelper.java`
2. Find the `insertSampleData()` method
3. Replace the sample data array with your data:

```java
private void insertSampleData(SQLiteDatabase db) {
    String[][] sampleData = {
        {"رقمك", "النتيجة بالعربية"},
        {"1", "نتيجة رقم واحد"},
        {"2", "نتيجة رقم اثنين"},
        {"3", "نتيجة رقم ثلاثة"},
        // Add your data here...
    };
    
    for (String[] row : sampleData) {
        String insertQuery = "INSERT INTO " + TABLE_NUMBERS + "(" +
                COLUMN_NUMBER + ", " + COLUMN_RESULT + ") VALUES (?, ?)";
        db.execSQL(insertQuery, new String[]{row[0], row[1]});
    }
}
```

---

## Method 3: SQL File Import

If you have a large SQLite database file:

### Steps:

1. Create a SQLite database file with your data
2. Copy it to: `app/src/main/assets/your_database.db`
3. Modify `DatabaseHelper.java` to copy and open the database file from assets

```java
@Override
public void onCreate(SQLiteDatabase db) {
    // Copy database from assets if it doesn't exist
    try {
        InputStream inputStream = context.getAssets().open("your_database.db");
        String outFileName = context.getDatabasePath(DATABASE_NAME).getPath();
        
        OutputStream outputStream = new FileOutputStream(outFileName);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
```

---

## Troubleshooting

### The app shows "لا توجد نتائج" (No results)

- Make sure your number is in the database
- Check the database content using Android Studio's Database Inspector
- Verify the CSV format is correct

### CSV file not loading

- Ensure the file is in `app/src/main/assets/` folder
- Check that the file name matches exactly (case-sensitive)
- Verify the CSV has the correct format with comma separation

### Database not updating

After changing the data source, you need to:
1. Uninstall the app from your device
2. Reinstall the app

OR

1. Increment `DATABASE_VERSION` in DatabaseHelper.java
2. Rebuild and reinstall

---

## CSV Format Example

Your CSV should look like this:

```csv
number,result
1,هذا هو النص للرقم واحد
2,هذا هو النص للرقم اثنين
10,هذا هو النص للرقم عشرة
20,هذا هو النص للرقم عشرين
```

**Important:** 
- The first line is the header (column names)
- Number can be any text or number
- Result should be your Arabic text
- Use UTF-8 encoding to preserve Arabic characters correctly

