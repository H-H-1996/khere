package com.khere.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper class for managing SQLite database
 * 
 * To add your own Excel data:
 * 1. Export Excel to CSV format (number,result columns)
 * 2. Replace the file in app/src/main/assets/sample_data.csv
 * 3. Uncomment the loadFromAssets() call in onCreate() method
 * 4. Comment out or remove insertSampleData(db) call
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "numbers_db";
    private static final int DATABASE_VERSION = 1;
    
    private static final String TABLE_NUMBERS = "numbers";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NUMBER = "number";
    private static final String COLUMN_RESULT = "result";
    
    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NUMBERS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NUMBER + " TEXT NOT NULL," +
                COLUMN_RESULT + " TEXT NOT NULL" +
                ")";
        db.execSQL(createTable);
        
        // Insert sample Arabic data
        insertSampleData(db);
        
        // To use your Excel data from CSV file, uncomment the following lines:
         try {
             loadDataFromAssets(db);
         } catch (Exception e) {
        //     // Fall back to sample data if asset file not found
            insertSampleData(db);
         }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NUMBERS);
        onCreate(db);
    }

    private void insertSampleData(SQLiteDatabase db) {
        // Sample Arabic data - you can replace this with your Excel data
        String[][] sampleData = {
            {"1", "نتيجة رقم واحد - هذا هو النص المقترن بالرقم"},
            {"2", "نتيجة رقم اثنين - هذه المعلومات تخص الرقم الثاني"},
            {"3", "نتيجة رقم ثلاثة - معلومات إضافية للرقم الثالث"},
            {"10", "نتيجة رقم عشرة - تفاصيل مهمة"},
            {"20", "نتيجة رقم عشرين - معلومات جديدة"},
            {"50", "نتيجة رقم خمسين - تفاصيل واسعة"},
            {"100", "نتيجة رقم مائة - معلومات شاملة"},
            {"500", "نتيجة رقم خمسمائة - تفاصيل دقيقة"},
            {"1000", "نتيجة رقم ألف - معلومات قيمة"}
        };
        
        for (String[] row : sampleData) {
            String insertQuery = "INSERT INTO " + TABLE_NUMBERS + "(" +
                    COLUMN_NUMBER + ", " + COLUMN_RESULT + ") VALUES (?, ?)";
            db.execSQL(insertQuery, new String[]{row[0], row[1]});
        }
    }

    public String searchByNumber(String number) {
        SQLiteDatabase db = this.getReadableDatabase();
        String result = null;
        
        String query = "SELECT " + COLUMN_RESULT + " FROM " + TABLE_NUMBERS +
                " WHERE " + COLUMN_NUMBER + " = ?";
        
        Cursor cursor = db.rawQuery(query, new String[]{number});
        
        if (cursor.moveToFirst()) {
            result = cursor.getString(0);
        }
        
        cursor.close();
        db.close();
        
        return result;
    }

    public List<String> getAllNumbers() {
        List<String> numbers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        
        String query = "SELECT " + COLUMN_NUMBER + " FROM " + TABLE_NUMBERS;
        Cursor cursor = db.rawQuery(query, null);
        
        while (cursor.moveToNext()) {
            numbers.add(cursor.getString(0));
        }
        
        cursor.close();
        db.close();
        
        return numbers;
    }
    
    /**
     * Load data from CSV file in assets folder
     * Place your Excel data.csv file in app/src/main/assets/ folder
     * 
     * @param db SQLite database instance
     */
    private void loadDataFromAssets(SQLiteDatabase db) {
        try {
            List<String[]> csvData = ExcelImportHelper.readCSVFromAssets(
                context, "sample_data.csv");
            
            String insertQuery = "INSERT INTO " + TABLE_NUMBERS + "(" +
                    COLUMN_NUMBER + ", " + COLUMN_RESULT + ") VALUES (?, ?)";
            
            // Skip header row
            for (int i = 1; i < csvData.size(); i++) {
                String[] row = csvData.get(i);
                if (row.length >= 2) {
                    db.execSQL(insertQuery, new String[]{
                        row[0].trim(), 
                        row[1].trim()
                    });
                }
            }
        } catch (Exception e) {
            // If file not found, fall back to sample data
            insertSampleData(db);
        }
    }
}

