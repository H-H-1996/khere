# Installation Guide

## Quick Start

This is an Android application that searches for Arabic text by number. Follow these steps to build and run the app.

## Prerequisites

- **Android Studio** (latest version recommended)
  - Download from: https://developer.android.com/studio
- **Java JDK 8 or later**
- **Android SDK** (API level 21 or higher)
- **Android device** or emulator with Android 5.0 (Lollipop) or higher

## Building the App

### Option 1: Using Android Studio (Recommended)

1. **Open the Project**
   - Launch Android Studio
   - Click "Open an Existing Project"
   - Navigate to the project folder
   - Click "OK"

2. **Wait for Gradle Sync**
   - Android Studio will automatically download dependencies
   - This may take a few minutes on first run

3. **Connect Your Device**
   - **Physical Device**: Enable USB debugging on your Android phone
     - Go to Settings → About phone → Tap "Build number" 7 times
     - Go to Settings → Developer options → Enable "USB debugging"
   - **Emulator**: Create a new virtual device
     - Click "Device Manager" in Android Studio
     - Click "Create Device"
     - Choose a device (e.g., Pixel 4)
     - Download a system image (API 21 or higher)
     - Click "Finish"

4. **Run the App**
   - Click the green "Run" button
   - Or press `Shift + F10`
   - Select your connected device
   - Wait for the app to install and launch

### Option 2: Using Command Line

1. **Install Android SDK Command-line Tools**
   - Follow: https://developer.android.com/studio/command-line

2. **Set Environment Variables**
   ```bash
   export ANDROID_HOME=/path/to/android/sdk
   export PATH=$PATH:$ANDROID_HOME/platform-tools
   ```

3. **Build the APK**
   ```bash
   cd /path/to/project
   ./gradlew assembleDebug
   ```

4. **Install on Device**
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

## Adding Your Excel Data

Before running the app, you should add your own Excel data. See `HOW_TO_ADD_EXCEL_DATA.md` for detailed instructions.

**Quick Method:**
1. Export your Excel to CSV format
2. Replace `app/src/main/assets/sample_data.csv`
3. Follow the instructions in the file

## Troubleshooting

### Build Errors

**Error: "SDK location not found"**
- Solution: Create `local.properties` file in project root
- Add: `sdk.dir=/path/to/android/sdk`

**Error: "Could not find com.android.tools.build:gradle"**
- Solution: Check internet connection, Gradle needs to download dependencies

**Error: "compileSdk 33 not found"**
- Solution: Install SDK 33 via Android Studio SDK Manager

### Runtime Errors

**App crashes on startup**
- Check logcat in Android Studio for error details
- Make sure minSdk is 21 or lower

**"لا توجد نتائج" (No results)**
- Your data is not in the database
- Add your Excel data first (see HOW_TO_ADD_EXCEL_DATA.md)

### Device Connection Issues

**Device not detected**
- Install USB drivers for your device
- Enable USB debugging on device
- Try different USB cable
- Use Wi-Fi debugging (Android 11+)

## Project Structure

```
app/
├── src/main/
│   ├── java/com/khere/app/
│   │   ├── MainActivity.java          # Main UI logic
│   │   ├── DatabaseHelper.java       # Database operations
│   │   └── ExcelImportHelper.java    # CSV import utility
│   ├── res/
│   │   ├── layout/
│   │   │   └── activity_main.xml     # UI layout
│   │   └── values/
│   │       ├── strings.xml            # English strings
│   │       ├── strings.xml (values-ar) # Arabic strings
│   │       ├── colors.xml             # App colors
│   │       └── styles.xml             # App theme
│   ├── assets/
│   │   └── sample_data.csv           # Your Excel data (CSV format)
│   └── AndroidManifest.xml            # App configuration
└── build.gradle                        # Build configuration
```

## Testing the App

1. Launch the app
2. Try entering these sample numbers: 1, 2, 3, 10, 20, 50, 100, 500, 1000
3. You should see Arabic results
4. Enter a number that doesn't exist (e.g., 999)
5. You should see "لا توجد نتائج"

## Customization

### Change App Icon
Replace files in `app/src/main/res/mipmap-*/` folders

### Change App Name
Edit `app/src/main/res/values/strings.xml`

### Change Colors
Edit `app/src/main/res/values/colors.xml`

## Requirements

- **Minimum SDK**: 21 (Android 5.0 Lollipop)
- **Target SDK**: 33 (Android 13)
- **Dependencies**:
  - AndroidX AppCompat
  - Material Design Components
  - ConstraintLayout
  - CardView

## Support

For issues or questions:
1. Check the code comments in Java files
2. Review HOW_TO_ADD_EXCEL_DATA.md
3. Check Android Studio's logcat for error messages

## License

This project is open source and available for modification.

