package com.khere.app;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper class to import data from CSV files (exported from Excel)
 * Place your Excel data.csv file in app/src/main/assets/ folder
 */
public class ExcelImportHelper {
    
    /**
     * Read CSV file from assets folder
     * 
     * @param context Application context
     * @param filename Name of the CSV file in assets folder
     * @return List of string arrays representing rows
     */
    public static List<String[]> readCSVFromAssets(Context context, String filename) {
        List<String[]> data = new ArrayList<>();
        AssetManager assetManager = context.getAssets();
        
        try {
            InputStream inputStream = assetManager.open(filename);
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8));
            
            String line;
            while ((line = reader.readLine()) != null) {
                String[] row = line.split(",");
                data.add(row);
            }
            
            reader.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return data;
    }
    
    /**
     * Convert Excel-like data format to array
     * Format: {"number", "arabic_result"}
     * 
     * @param data List of string arrays from CSV
     * @return 2D array ready for database insertion
     */
    public static String[][] convertToArray(List<String[]> data) {
        List<String[]> converted = new ArrayList<>();
        
        for (String[] row : data) {
            if (row.length >= 2) {
                converted.add(new String[]{row[0].trim(), row[1].trim()});
            }
        }
        
        return converted.toArray(new String[converted.size()][]);
    }
}

