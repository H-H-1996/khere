# Quick setup script based on your choice

Write-Host "===========================================" -ForegroundColor Cyan
Write-Host "  Choose Your Build Path" -ForegroundColor Cyan
Write-Host "===========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Java is installed! ✓" -ForegroundColor Green
Write-Host ""
Write-Host "Options:" -ForegroundColor Yellow
Write-Host "  1. GitHub Actions (Cloud Build) - RECOMMENDED" -ForegroundColor White
Write-Host "  2. Install Android Studio" -ForegroundColor White
Write-Host "  3. Manual SDK setup" -ForegroundColor White
Write-Host "  4. Create ZIP for manual upload" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Enter your choice (1-4)"

switch ($choice) {
    "1" {
        Write-Host ""
        Write-Host "Installing Git..." -ForegroundColor Yellow
        winget install --id Git.Git -e --silent
        
        Write-Host ""
        Write-Host "Setting up Git repository..." -ForegroundColor Yellow
        
        git init
        git config user.name "YourName"
        git config user.email "your@email.com"
        git add .
        git commit -m "Initial commit"
        
        Write-Host ""
        Write-Host "Next steps:" -ForegroundColor Cyan
        Write-Host "  1. Create GitHub account: https://github.com/signup" -ForegroundColor White
        Write-Host "  2. Create repository named 'khere'" -ForegroundColor White
        Write-Host "  3. Copy the repository URL" -ForegroundColor White
        Write-Host "  4. Run: git remote add origin <YOUR_REPO_URL>" -ForegroundColor White
        Write-Host "  5. Run: git push -u origin main" -ForegroundColor White
        Write-Host ""
        Write-Host "The APK will build automatically in the cloud!" -ForegroundColor Green
    }
    
    "2" {
        Write-Host ""
        Write-Host "Installing Android Studio..." -ForegroundColor Yellow
        Write-Host "This will download ~2GB and take 30+ minutes" -ForegroundColor Gray
        winget install --id Google.AndroidStudio -e --silent
        
        Write-Host ""
        Write-Host "After installation:" -ForegroundColor Cyan
        Write-Host "  1. Open Android Studio" -ForegroundColor White
        Write-Host "  2. Open this project" -ForegroundColor White
        Write-Host "  3. Build → Build APK" -ForegroundColor White
    }
    
    "3" {
        Write-Host ""
        Write-Host "Manual SDK setup guide:" -ForegroundColor Yellow
        Write-Host "See: BUILD_OPTIONS.md (Option 3)" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Or see: BUILD_WITHOUT_ANDROID_STUDIO.md" -ForegroundColor Cyan
    }
    
    "4" {
        Write-Host ""
        Write-Host "Creating ZIP file..." -ForegroundColor Yellow
        Compress-Archive -Path * -DestinationPath "khere_project.zip" -Force
        
        Write-Host ""
        Write-Host "ZIP created: khere_project.zip" -ForegroundColor Green
        Write-Host ""
        Write-Host "Upload to GitHub:" -ForegroundColor Cyan
        Write-Host "  1. Go to https://github.com/new" -ForegroundColor White
        Write-Host "  2. Create repository 'khere'" -ForegroundColor White
        Write-Host "  3. Upload this ZIP" -ForegroundColor White
        Write-Host "  4. GitHub Actions will build automatically!" -ForegroundColor White
    }
    
    default {
        Write-Host "Invalid choice" -ForegroundColor Red
    }
}

