# PowerShell script to build APK using Android Studio Gradle

Write-Host "===============================================" -ForegroundColor Cyan
Write-Host "  Building APK for Arabic Number Search App" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""

# Check if Android Studio Gradle is available
$androidHome = $env:ANDROID_HOME
$sdkPath = $null

if ($androidHome) {
    $sdkPath = $androidHome
    Write-Host "Using ANDROID_HOME: $androidHome" -ForegroundColor Green
}
else {
    # Try common Android Studio installation paths
    $commonPaths = @(
        "$env:LOCALAPPDATA\Android\Sdk",
        "$env:ProgramFiles\Android\Sdk",
        "$env:ProgramFiles(x86)\Android\Sdk",
        "C:\Android\Sdk"
    )
    
    foreach ($path in $commonPaths) {
        if (Test-Path $path) {
            $sdkPath = $path
            Write-Host "Found Android SDK at: $sdkPath" -ForegroundColor Green
            $env:ANDROID_HOME = $sdkPath
            break
        }
    }
}

if (-not $sdkPath) {
    Write-Host "ERROR: Android SDK not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install Android Studio or set ANDROID_HOME environment variable." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Alternative: Use Android Studio to build:" -ForegroundColor Cyan
    Write-Host "  1. Open Android Studio" -ForegroundColor White
    Write-Host "  2. Open this project" -ForegroundColor White
    Write-Host "  3. Build → Build Bundle(s) / APK(s) → Build APK(s)" -ForegroundColor White
    exit 1
}

# Check if gradlew.bat exists
if (-not (Test-Path "gradlew.bat")) {
    Write-Host "ERROR: gradlew.bat not found!" -ForegroundColor Red
    Write-Host "Please run this script from the project root directory." -ForegroundColor Yellow
    exit 1
}

# Create gradle wrapper jar if it doesn't exist
$wrapperJar = "gradle\wrapper\gradle-wrapper.jar"
if (-not (Test-Path $wrapperJar)) {
    Write-Host "Creating gradle wrapper..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Force -Path "gradle\wrapper" | Out-Null
    # Download gradle wrapper jar
    Write-Host "Please use Android Studio instead." -ForegroundColor Yellow
    exit 1
}

Write-Host "Building APK..." -ForegroundColor Yellow
Write-Host ""

# Try to build
try {
    & ".\gradlew.bat" assembleDebug
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "===============================================" -ForegroundColor Green
        Write-Host "  APK Built Successfully!" -ForegroundColor Green
        Write-Host "===============================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "APK Location:" -ForegroundColor Cyan
        Write-Host "  app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor White
        Write-Host ""
    }
    else {
        Write-Host "Build failed!" -ForegroundColor Red
        Write-Host "Please use Android Studio to build the APK." -ForegroundColor Yellow
    }
}
catch {
    Write-Host "Error building APK:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Please use Android Studio to build the APK." -ForegroundColor Yellow
}

