# How to Build the APK

## Quick Method: Using Android Studio

### Step 1: Open the Project
1. Open Android Studio
2. Click "Open an Existing Project"
3. Navigate to `C:\Users\Admin\Desktop\khere`
4. Click "OK"

### Step 2: Wait for Sync
- Android Studio will automatically download Gradle and dependencies
- This may take a few minutes on first run
- Wait for the sync to complete (progress bar at bottom)

### Step 3: Build APK
1. Go to **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Wait for the build to complete
3. When done, you'll see a notification: "APK(s) generated successfully"
4. Click the "locate" link in the notification

### Step 4: Find Your APK
The APK will be located at:
```
app\build\outputs\apk\debug\app-debug.apk
```

## Alternative: Using Command Line

If you have Android SDK installed:

### Option 1: Using Android Studio Terminal
1. Open Android Studio terminal (bottom panel)
2. Navigate to project: `cd C:\Users\Admin\Desktop\khere`
3. Run: `.\gradlew.bat assembleDebug`

### Option 2: Using PowerShell
1. Open PowerShell as Administrator
2. Navigate to project:
   ```powershell
   cd C:\Users\Admin\Desktop\khere
   ```
3. Run:
   ```powershell
   .\gradlew.bat assembleDebug
   ```

**Note:** If you get "JAVA_HOME is not set" error:
- You need to install Java JDK
- Or use Android Studio method instead (easiest)

## Installing the APK on Your Phone

### Method 1: Using USB
1. Connect your phone to the computer via USB
2. Enable USB Debugging on your phone:
   - Settings → About phone → Tap "Build number" 7 times
   - Settings → Developer options → Enable "USB debugging"
3. Run this command:
   ```powershell
   adb install app\build\outputs\apk\debug\app-debug.apk
   ```

### Method 2: Transfer and Install
1. Copy `app-debug.apk` to your phone
2. On your phone: Settings → Security → Enable "Install from unknown sources"
3. Open the APK file on your phone and install

## Building Release APK (Optional)

For a signed release APK:
1. In Android Studio: **Build** → **Generate Signed Bundle / APK**
2. Create a keystore (first time only)
3. Complete the signing wizard
4. The release APK will be in: `app\build\outputs\apk\release\`

## Troubleshooting

**"SDK not found" error**
- Solution: Use Android Studio (it includes the SDK)

**"Gradle sync failed"**
- Solution: Check internet connection, Gradle needs to download dependencies

**"JAVA_HOME is not set"**
- Solution: Use Android Studio instead of command line

**APK won't install on phone**
- Enable "Install from unknown sources" in phone settings
- Make sure the phone allows installation from the source you're using

## Recommended: Use Android Studio

The easiest way is to use Android Studio:
1. It includes all necessary tools (Java, Gradle, SDK)
2. One-click build process
3. Built-in debugger and testing tools
4. Automatic dependency management

