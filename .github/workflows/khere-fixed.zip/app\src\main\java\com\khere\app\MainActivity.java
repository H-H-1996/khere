package com.khere.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText etNumber;
    private Button btnSearch;
    private CardView cardResult;
    private TextView tvResult;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        dbHelper = new DatabaseHelper(this);
        
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchNumber();
            }
        });
    }

    private void initializeViews() {
        etNumber = findViewById(R.id.etNumber);
        btnSearch = findViewById(R.id.btnSearch);
        cardResult = findViewById(R.id.cardResult);
        tvResult = findViewById(R.id.tvResult);
    }

    private void searchNumber() {
        String number = etNumber.getText().toString().trim();
        
        if (number.isEmpty()) {
            Toast.makeText(this, R.string.enter_valid_number, Toast.LENGTH_SHORT).show();
            cardResult.setVisibility(View.GONE);
            return;
        }

        String result = dbHelper.searchByNumber(number);
        
        if (result != null) {
            tvResult.setText(result);
            cardResult.setVisibility(View.VISIBLE);
        } else {
            Toast.makeText(this, R.string.no_results, Toast.LENGTH_SHORT).show();
            cardResult.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}

